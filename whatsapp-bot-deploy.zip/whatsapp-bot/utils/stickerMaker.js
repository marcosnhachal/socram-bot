const sharp = require('sharp');
const fs = require('fs-extra');
const path = require('path');

class StickerMaker {
    constructor() {
        this.tempPath = path.join(__dirname, '../temp');
        this.outputPath = path.join(__dirname, '../downloads');
        
        // Garantir que os diretórios existem
        fs.ensureDirSync(this.tempPath);
        fs.ensureDirSync(this.outputPath);
    }

    /**
     * Cria um sticker a partir de uma imagem
     * @param {Buffer} imageBuffer - Buffer da imagem
     * @param {Object} options - Opções de configuração
     * @returns {Promise<Buffer>} Buffer do sticker em WebP
     */
    async createSticker(imageBuffer, options = {}) {
        try {
            const {
                quality = 80,
                background = { r: 255, g: 255, b: 255, alpha: 0 },
                addBorder = false,
                borderColor = { r: 255, g: 255, b: 255, alpha: 1 },
                borderWidth = 10
            } = options;

            let image = sharp(imageBuffer);
            
            // Obter metadados da imagem
            const metadata = await image.metadata();
            
            // Calcular dimensões para manter proporção
            const maxSize = 512;
            let width, height;
            
            if (metadata.width > metadata.height) {
                width = maxSize;
                height = Math.round((metadata.height * maxSize) / metadata.width);
            } else {
                height = maxSize;
                width = Math.round((metadata.width * maxSize) / metadata.height);
            }

            // Redimensionar imagem
            image = image.resize(width, height, {
                fit: 'inside',
                withoutEnlargement: false
            });

            // Adicionar borda se solicitado
            if (addBorder) {
                image = image.extend({
                    top: borderWidth,
                    bottom: borderWidth,
                    left: borderWidth,
                    right: borderWidth,
                    background: borderColor
                });
            }

            // Garantir que a imagem final seja 512x512
            image = image.resize(512, 512, {
                fit: 'contain',
                background: background
            });

            // Converter para WebP
            const webpBuffer = await image
                .webp({ 
                    quality: quality,
                    effort: 6,
                    lossless: false
                })
                .toBuffer();

            return webpBuffer;
        } catch (error) {
            throw new Error(`Erro ao criar sticker: ${error.message}`);
        }
    }

    /**
     * Cria sticker a partir de arquivo
     * @param {string} filePath - Caminho do arquivo de imagem
     * @param {Object} options - Opções de configuração
     * @returns {Promise<Buffer>} Buffer do sticker
     */
    async createStickerFromFile(filePath, options = {}) {
        try {
            const imageBuffer = await fs.readFile(filePath);
            return await this.createSticker(imageBuffer, options);
        } catch (error) {
            throw new Error(`Erro ao ler arquivo: ${error.message}`);
        }
    }

    /**
     * Cria sticker animado a partir de GIF
     * @param {Buffer} gifBuffer - Buffer do GIF
     * @param {Object} options - Opções de configuração
     * @returns {Promise<Buffer>} Buffer do sticker animado
     */
    async createAnimatedSticker(gifBuffer, options = {}) {
        try {
            const { quality = 80 } = options;
            
            // Para GIFs animados, usar sharp com configurações específicas
            const webpBuffer = await sharp(gifBuffer, { animated: true })
                .resize(512, 512, {
                    fit: 'contain',
                    background: { r: 255, g: 255, b: 255, alpha: 0 }
                })
                .webp({ 
                    quality: quality,
                    effort: 6,
                    lossless: false
                })
                .toBuffer();

            return webpBuffer;
        } catch (error) {
            throw new Error(`Erro ao criar sticker animado: ${error.message}`);
        }
    }

    /**
     * Cria sticker com texto
     * @param {string} text - Texto para o sticker
     * @param {Object} options - Opções de configuração
     * @returns {Promise<Buffer>} Buffer do sticker
     */
    async createTextSticker(text, options = {}) {
        try {
            const {
                fontSize = 60,
                fontColor = '#000000',
                backgroundColor = '#FFFFFF',
                padding = 50,
                fontFamily = 'Arial'
            } = options;

            // Criar SVG com texto
            const svgText = `
                <svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
                    <rect width="512" height="512" fill="${backgroundColor}"/>
                    <text x="256" y="256" 
                          font-family="${fontFamily}" 
                          font-size="${fontSize}" 
                          fill="${fontColor}" 
                          text-anchor="middle" 
                          dominant-baseline="middle"
                          style="word-wrap: break-word;">
                        ${text}
                    </text>
                </svg>
            `;

            const webpBuffer = await sharp(Buffer.from(svgText))
                .resize(512, 512)
                .webp({ quality: 90 })
                .toBuffer();

            return webpBuffer;
        } catch (error) {
            throw new Error(`Erro ao criar sticker de texto: ${error.message}`);
        }
    }

    /**
     * Salva sticker em arquivo
     * @param {Buffer} stickerBuffer - Buffer do sticker
     * @param {string} fileName - Nome do arquivo (sem extensão)
     * @returns {Promise<string>} Caminho do arquivo salvo
     */
    async saveStickerToFile(stickerBuffer, fileName) {
        try {
            const sanitizedName = this.sanitizeFileName(fileName);
            const filePath = path.join(this.outputPath, `${sanitizedName}.webp`);
            
            await fs.writeFile(filePath, stickerBuffer);
            return filePath;
        } catch (error) {
            throw new Error(`Erro ao salvar sticker: ${error.message}`);
        }
    }

    /**
     * Verifica se o arquivo é uma imagem válida
     * @param {Buffer} buffer - Buffer do arquivo
     * @returns {Promise<boolean>} True se for uma imagem válida
     */
    async isValidImage(buffer) {
        try {
            const metadata = await sharp(buffer).metadata();
            return metadata.format !== undefined;
        } catch (error) {
            return false;
        }
    }

    /**
     * Obtém informações da imagem
     * @param {Buffer} buffer - Buffer da imagem
     * @returns {Promise<Object>} Metadados da imagem
     */
    async getImageInfo(buffer) {
        try {
            const metadata = await sharp(buffer).metadata();
            return {
                width: metadata.width,
                height: metadata.height,
                format: metadata.format,
                size: buffer.length,
                hasAlpha: metadata.hasAlpha
            };
        } catch (error) {
            throw new Error(`Erro ao obter informações da imagem: ${error.message}`);
        }
    }

    /**
     * Limpa nome do arquivo removendo caracteres inválidos
     * @param {string} fileName - Nome original do arquivo
     * @returns {string} Nome sanitizado
     */
    sanitizeFileName(fileName) {
        return fileName
            .replace(/[<>:"/\\|?*]/g, '')
            .replace(/\s+/g, '_')
            .substring(0, 50);
    }

    /**
     * Remove arquivos temporários antigos
     * @param {number} maxAge - Idade máxima em horas
     */
    async cleanTempFiles(maxAge = 1) {
        try {
            const files = await fs.readdir(this.tempPath);
            const now = Date.now();
            
            for (const file of files) {
                const filePath = path.join(this.tempPath, file);
                const stats = await fs.stat(filePath);
                const ageInHours = (now - stats.mtime.getTime()) / (1000 * 60 * 60);
                
                if (ageInHours > maxAge) {
                    await fs.remove(filePath);
                    console.log(`Arquivo temporário removido: ${file}`);
                }
            }
        } catch (error) {
            console.error('Erro ao limpar arquivos temporários:', error.message);
        }
    }
}

module.exports = StickerMaker;

