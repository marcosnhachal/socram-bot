const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');

class MusicDownloader {
    constructor() {
        this.downloadPath = path.join(__dirname, '../downloads');
        this.tempPath = path.join(__dirname, '../temp');
        
        // Garantir que os diretórios existem
        fs.ensureDirSync(this.downloadPath);
        fs.ensureDirSync(this.tempPath);
    }

    /**
     * Busca informações de um vídeo do YouTube
     * @param {string} query - URL ou termo de busca
     * @returns {Promise<Object>} Informações do vídeo
     */
    async getVideoInfo(query) {
        return new Promise((resolve, reject) => {
            const isUrl = query.includes('youtube.com') || query.includes('youtu.be');
            const searchQuery = isUrl ? query : `ytsearch1:"${query}"`;
            
            const command = `yt-dlp --dump-json "${searchQuery}"`;
            
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`Erro ao buscar vídeo: ${error.message}`));
                    return;
                }
                
                try {
                    const videoInfo = JSON.parse(stdout.trim());
                    resolve({
                        title: videoInfo.title,
                        duration: videoInfo.duration,
                        uploader: videoInfo.uploader,
                        url: videoInfo.webpage_url,
                        id: videoInfo.id
                    });
                } catch (parseError) {
                    reject(new Error(`Erro ao processar informações do vídeo: ${parseError.message}`));
                }
            });
        });
    }

    /**
     * Baixa áudio de um vídeo do YouTube
     * @param {string} query - URL ou termo de busca
     * @param {string} format - Formato do áudio (mp3, m4a, etc.)
     * @returns {Promise<string>} Caminho do arquivo baixado
     */
    async downloadAudio(query, format = 'mp3') {
        return new Promise(async (resolve, reject) => {
            try {
                const videoInfo = await this.getVideoInfo(query);
                const fileName = this.sanitizeFileName(videoInfo.title);
                const outputPath = path.join(this.downloadPath, `${fileName}.${format}`);
                
                // Verificar se o arquivo já existe
                if (fs.existsSync(outputPath)) {
                    resolve(outputPath);
                    return;
                }
                
                const isUrl = query.includes('youtube.com') || query.includes('youtu.be');
                const searchQuery = isUrl ? query : `ytsearch1:"${query}"`;
                
                const command = `yt-dlp -x --audio-format ${format} --audio-quality 0 -o "${this.downloadPath}/%(title)s.%(ext)s" "${searchQuery}"`;
                
                exec(command, { maxBuffer: 1024 * 1024 * 10 }, (error, stdout, stderr) => {
                    if (error) {
                        reject(new Error(`Erro ao baixar áudio: ${error.message}`));
                        return;
                    }
                    
                    // Encontrar o arquivo baixado
                    const files = fs.readdirSync(this.downloadPath);
                    const downloadedFile = files.find(file => 
                        file.includes(fileName.substring(0, 20)) && file.endsWith(`.${format}`)
                    );
                    
                    if (downloadedFile) {
                        const finalPath = path.join(this.downloadPath, downloadedFile);
                        resolve(finalPath);
                    } else {
                        reject(new Error('Arquivo baixado não encontrado'));
                    }
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    /**
     * Busca múltiplas músicas
     * @param {string} query - Termo de busca
     * @param {number} limit - Número máximo de resultados
     * @returns {Promise<Array>} Lista de vídeos encontrados
     */
    async searchMusic(query, limit = 5) {
        return new Promise((resolve, reject) => {
            const command = `yt-dlp --dump-json "ytsearch${limit}:${query}"`;
            
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`Erro na busca: ${error.message}`));
                    return;
                }
                
                try {
                    const lines = stdout.trim().split('\n');
                    const results = lines.map(line => {
                        const videoInfo = JSON.parse(line);
                        return {
                            title: videoInfo.title,
                            duration: this.formatDuration(videoInfo.duration),
                            uploader: videoInfo.uploader,
                            url: videoInfo.webpage_url,
                            id: videoInfo.id
                        };
                    });
                    
                    resolve(results);
                } catch (parseError) {
                    reject(new Error(`Erro ao processar resultados da busca: ${parseError.message}`));
                }
            });
        });
    }

    /**
     * Limpa nome do arquivo removendo caracteres inválidos
     * @param {string} fileName - Nome original do arquivo
     * @returns {string} Nome sanitizado
     */
    sanitizeFileName(fileName) {
        return fileName
            .replace(/[<>:"/\\|?*]/g, '')
            .replace(/\s+/g, '_')
            .substring(0, 100);
    }

    /**
     * Formata duração em segundos para mm:ss
     * @param {number} seconds - Duração em segundos
     * @returns {string} Duração formatada
     */
    formatDuration(seconds) {
        if (!seconds) return 'N/A';
        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }

    /**
     * Remove arquivos antigos para economizar espaço
     * @param {number} maxAge - Idade máxima em horas
     */
    async cleanOldFiles(maxAge = 24) {
        const files = await fs.readdir(this.downloadPath);
        const now = Date.now();
        
        for (const file of files) {
            const filePath = path.join(this.downloadPath, file);
            const stats = await fs.stat(filePath);
            const ageInHours = (now - stats.mtime.getTime()) / (1000 * 60 * 60);
            
            if (ageInHours > maxAge) {
                await fs.remove(filePath);
                console.log(`Arquivo removido: ${file}`);
            }
        }
    }
}

module.exports = MusicDownloader;

